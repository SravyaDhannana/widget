import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: [ './employees.component.css' ]
})
export class EmployeesComponent  {

  employeeList: any;
  keys: any;

  selectedEmployee: any;
  newEmployee: any;
  constructor(private httpClient: HttpClient ){
    this.getEmployees();
  }

  getEmployees() {
     this.httpClient.get('https://jsonplaceholder.typicode.com/users').subscribe(data => {
      this.employeeList = data;
      console.log(this.employeeList);
    })
  }

  editEmployee(employee: any) {
    this.selectedEmployee =employee;
    employee.isEditable=!employee.isEditable
    this.httpClient.post('https://jsonplaceholder.typicode.com/users',employee);
    
  }

  deleteEmployee(employee: any){
    this.httpClient.delete('https://jsonplaceholder.typicode.com/users'+ '/' + employee.id).subscribe( data => {
        this.employeeList = this.employeeList.filter(u => u !== employee);
    })
    
  }
  
  addEmployee(newEmp: any) {
    console.log(newEmp);
  }

  onSubmit() {
    console.log();
  }
}
